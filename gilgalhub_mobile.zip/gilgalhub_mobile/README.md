# 🎧 GilgalHub Mobile App

**Built in Nigeria, made for you.**  
GilgalHub empowers creators to monetize directly, fans to discover music by humming or whistling, and communities to connect through sound, AI, and culture.

## 🚀 Features

- 🔐 JWT Authentication via Firebase
- 🎤 Voice Discovery UI (AI integration coming soon)
- 🧑‍🎤 Creator Dashboard for uploads and analytics
- 📩 Fan Messaging with voice notes
- 💸 Monetization via Stripe (web integration)
- 🌍 Cultural Preservation & Geo-triggered drops (roadmap)

## 📱 Tech Stack

- **Flutter** for cross-platform mobile development
- **Firebase** for auth and messaging
- **Node.js** (planned) for AI and smart contracts
- **Bubble.io** for web dashboard

## 🧠 Future Enhancements

- AI Song Recognition
- Emotion-based discovery
- Digital Twin Artists
- Creator Smart Contracts

## 🛠️ Setup Instructions

1. Clone the repo
2. Run `flutter pub get`
3. Add Firebase config files
4. Run `flutter run`

---

## 🤝 Contributing

Want to help preserve indigenous sounds or build the remix engine? Fork the repo and let’s collaborate.

---

## 📜 License

MIT License — free to use, remix, and build upon.
