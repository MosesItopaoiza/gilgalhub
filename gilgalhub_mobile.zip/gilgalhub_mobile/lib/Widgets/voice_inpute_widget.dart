import 'package:flutter/material.dart';

class VoiceInputWidget extends StatelessWidget {
  final VoidCallback onStart;
  final VoidCallback onStop;

  const VoiceInputWidget({required this.onStart, required this.onStop});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(Icons.mic, size: 80, color: Colors.deepPurple),
        SizedBox(height: 10),
        Text("Tap to record your voice"),
        SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: onStart, child: Text("Start")),
            SizedBox(width: 10),
            ElevatedButton(onPressed: onStop, child: Text("Stop")),
          ],
        ),
      ],
    );
  }
}
