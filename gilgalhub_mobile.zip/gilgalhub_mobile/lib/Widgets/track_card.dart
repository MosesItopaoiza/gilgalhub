import 'package:flutter/material.dart';

class TrackCard extends StatelessWidget {
  final String title;
  final String artist;
  final VoidCallback onPlay;

  const TrackCard({required this.title, required this.artist, required this.onPlay});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        leading: Icon(Icons.music_note, color: Colors.deepPurple),
        title: Text(title),
        subtitle: Text(artist),
        trailing: IconButton(
          icon: Icon(Icons.play_arrow),
          onPressed: onPlay,
        ),
      ),
    );
  }
}
