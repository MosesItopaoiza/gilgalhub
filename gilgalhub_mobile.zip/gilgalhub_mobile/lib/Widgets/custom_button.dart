import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/discover_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/messaging_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  runApp(GilgalHubApp());
}

class GilgalHubApp extends StatefulWidget {
  @override
  _GilgalHubAppState createState() => _GilgalHubAppState();
}

class _GilgalHubAppState extends State<GilgalHubApp> {
  int _index = 0;
  final screens = [
    DiscoverScreen(),
    MessagingScreen(),
    DashboardScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: screens[_index],
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _index,
          onTap: (i) => setState(() => _index = i),
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Discover'),
            BottomNavigationBarItem(icon: Icon(Icons.message), label: 'Messages'),
            BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: 'Dashboard'),
            BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
      ),
    );
  }
}
