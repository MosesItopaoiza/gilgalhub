import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Creator Dashboard")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text("Upload Track", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ElevatedButton(
              onPressed: () {
                // TODO: Upload logic
              },
              child: Text("Choose File"),
            ),
            Divider(),
            Text("Analytics", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ListTile(title: Text("Plays: 1,204")),
            ListTile(title: Text("Likes: 342")),
          ],
        ),
      ),
    );
  }
}
