import 'package:flutter/material.dart';
import 'login_screen.dart';

class OnboardingScreen extends StatelessWidget {
  final List<Map<String, String>> pages = [
    {
      'title': 'Discover Music by Voice',
      'subtitle': 'Hum, whistle, or sing to find your favorite tracks.',
    },
    {
      'title': 'Empower Creators',
      'subtitle': 'Upload, monetize, and connect with fans directly.',
    },
    {
      'title': 'Join the Culture',
      'subtitle': 'Experience sound, AI, and community — rooted in Africa.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView.builder(
        itemCount: pages.length,
        itemBuilder: (context, index) {
          return Container(
            padding: EdgeInsets.all(32),
            color: Colors.deepPurple[50],
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.graphic_eq, size: 80, color: Colors.deepPurple),
                SizedBox(height: 30),
                Text(
                  pages[index]['title']!,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                Text(
                  pages[index]['subtitle']!,
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 40),
                if (index == pages.length - 1)
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => LoginScreen()),
                      );
                    },
                    child: Text("Get Started"),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}
