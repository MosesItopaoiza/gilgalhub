import 'package:flutter/material.dart';

class MessagingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Fan Messages")),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.voice_chat),
            title: Text("Voice Note from Fan"),
            subtitle: Text("Tap to listen"),
            onTap: () {
              // TODO: Play voice note
            },
          ),
        ],
      ),
    );
  }
}
