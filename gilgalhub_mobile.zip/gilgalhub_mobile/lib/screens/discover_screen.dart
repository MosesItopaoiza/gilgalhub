import 'package:flutter/material.dart';

class DiscoverScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Discover")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.mic, size: 100, color: Colors.deepPurple),
            SizedBox(height: 20),
            Text("Hum, whistle, or sing to find music"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // TODO: Start voice recording
              },
              child: Text("Start Recording"),
            ),
          ],
        ),
      ),
    );
  }
}
