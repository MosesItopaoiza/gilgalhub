class TrackModel {
  final String id;
  final String title;
  final String artistId;
  final String audioUrl;
  final int playCount;
  final int likeCount;

  TrackModel({
    required this.id,
    required this.title,
    required this.artistId,
    required this.audioUrl,
    required this.playCount,
    required this.likeCount,
  });

  factory TrackModel.fromMap(Map<String, dynamic> data) {
    return TrackModel(
      id: data['id'],
      title: data['title'],
      artistId: data['artistId'],
      audioUrl: data['audioUrl'],
      playCount: data['playCount'] ?? 0,
      likeCount: data['likeCount'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'artistId': artistId,
      'audioUrl': audioUrl,
      'playCount': playCount,
      'likeCount': likeCount,
    };
  }
}
