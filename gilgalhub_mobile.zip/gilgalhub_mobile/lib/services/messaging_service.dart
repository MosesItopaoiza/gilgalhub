import 'package:cloud_firestore/cloud_firestore.dart';

class MessagingService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> sendMessage(String creatorId, String fanId, String audioUrl) async {
    try {
      await _db.collection('messages').add({
        'creatorId': creatorId,
        'fanId': fanId,
        'audioUrl': audioUrl,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print("Message Error: $e");
    }
  }

  Stream<QuerySnapshot> getMessagesForCreator(String creatorId) {
    return _db
        .collection('messages')
        .where('creatorId', isEqualTo: creatorId)
        .orderBy('timestamp', descending: true)
        .snapshots();
  }
}
